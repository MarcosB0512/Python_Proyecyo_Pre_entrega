from setuptools import setup


setup(
    name="primer_paquete_marcos_benavide",
    version="1.0",
    description="Primer paquete redistribuible",
    author="Marcos",
    author_email="marcosbenavide72@gmail.com",
    packages=["primer_paquete"]
)